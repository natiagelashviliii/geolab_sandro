## About Application

install applicaiton steps:

-- git clone https://github.com/natiagelashviliii/geolab_sandro.git
<br>
-- composer install
<br>
-- change env.example to .env
<br>
-- php artisan key:generate
<br>
-- make db geolab_sandro
<br>
-- php artisan migrate
<br>
-- php artisan db:seed

<div class="popup-content">

	<div>

		<div class="container project-popup-container">

			<?php echo $__env->make('works.inc.popup-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		</div>

		<div class="arrows">

			<button class="arrow left" onclick="projects.previous(this, <?php echo e($slugId ? $slugId : 0); ?>)" data-id="<?php echo e($previous); ?>">

				<img src="<?php echo e(asset('img/left.svg')); ?>">

			</button>

			<button class="arrow right" onclick="projects.next(this, <?php echo e($slugId ? $slugId : 0); ?>)" data-id="<?php echo e($next); ?>">

				<img src="<?php echo e(asset('img/left.svg')); ?>" style="transform: rotate(180deg);">

			</button>

		</div>

	</div>

	<div class="close"></div>

</div>
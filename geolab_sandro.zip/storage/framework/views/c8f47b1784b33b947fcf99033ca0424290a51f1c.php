       
<?php $__env->startSection('section'); ?>

<div class="row categories-content pd-all-40">
	<div class="col s12">
		<ul class="cat-list">
			<?php $__currentLoopData = $Cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<span class="title"><?php echo e($value->title); ?></span>
				<!-- <span class="cat-cnt">(works - 15)</span> -->
				<span class="actions right">
					<a href="<?php echo e(url('admin/categories/edit/'.$value->id)); ?>"><i class="large material-icons" title="Edit">edit</i></a>
					<a onclick="admin.deleteCategory(<?php echo e($value->id); ?>, this)"><i class="large material-icons" title="Delete">clear</i></a>
				</span>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<div class="col s12 right-align add-cat-btn">
		<a href="<?php echo e(url('admin/categories/add')); ?>" class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
	</div>
</div>        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plugins/fileinput.css')); ?>">
    <?php echo $__env->yieldContent('sub_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="row">
    <header class="admin-header">
        <ul class="admin-menu">
            <li><a <?php if(Request::is('admin/about')): ?> class="active-link" <?php endif; ?> href="<?php echo e(url('admin/about')); ?>">About</a></li>
            <li><a <?php if(Request::is('admin/works')): ?> class="active-link" <?php endif; ?> href="<?php echo e(url('admin/works')); ?>">Works</a></li>
            <li><a <?php if(Request::is('admin/contact')): ?> class="active-link" <?php endif; ?> href="<?php echo e(url('admin/contact')); ?>">Contact</a></li>
        </ul>
        <ul class="admin-menu admin-bottom-menu">
            <li><a <?php if(Request::is('admin/user')): ?> class="active-link" <?php endif; ?> href="<?php echo e(url('admin/user')); ?>">User</a></li>
            <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
        </ul>
        <button class="resp-menu-btn"><i class="large material-icons">more_vert</i></button>
    </header>

    <div class="admin-main col s12 m9 xl10 offset-xl2 offset-m3">
        <?php echo $__env->yieldContent('section'); ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <!-- <script src="<?php echo e(asset('js/plugins/files.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/plugins/jform.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/jalerts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/fileinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/files-sortable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/file-theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/files-fa-theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
    <?php echo $__env->yieldContent('sub_footer'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
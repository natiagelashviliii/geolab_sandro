       
<?php $__env->startSection('section'); ?>

<div class="row works-content pd-all-40">
	<div class="col s12">
		<div class="manage-categories">
			<a href="<?php echo e(url('admin/categories')); ?>" class="btn"><i class="material-icons left">settings</i>Manage Categories</a>
		</div>
	</div>
	<div class="col s12 add-cat-btn">
		<ul class="left filter">
			<?php if(Request::get('cat')): ?>
				<li class="filter-item clear"><a href="<?php echo e(url('admin/works')); ?>">all</a></li>
			<?php endif; ?>	
			<?php $__currentLoopData = $Cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="filter-item <?php echo e(Request::get('cat') && Request::get('cat') == $value->id ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/works/?cat=') . $value->id); ?>"><?php echo e($value->title); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<a href="<?php echo e(url('admin/works/add')); ?>" class="right btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
	</div>
	<div class="col s12 works">
		<div class="row">
		<?php $__currentLoopData = $Works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<div class="col s12 m6 l4 xl3 each-work">
				<div class="file">
					<?php if($value->file): ?>
					<img src="<?php echo e(asset('storage/works') . '/' . $value->file); ?>">
					<?php elseif($value->video): ?>
					<img src="<?php echo e($value->video_thumb); ?>">
					<?php endif; ?>
				</div>
				<div class="file-descr">
					<div class="title">
						<p class="mg-all-0 center-align"><?php echo e($value->title); ?></p>
					</div>
					<div class="descr">
						<p class="mg-all-0"><?php echo e(str_limit($value->description, $limit = 100, $end = '...')); ?></p>
					</div>
					<div class="tags">
						<?php $__currentLoopData = $value->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagKey => $tagVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span><a href="">#<?php echo e($tagVal->name); ?></a></span>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="category">
						<span>Category: <a href=""><?php echo e($value->cat_title); ?></a></span>
					</div>
					<div class="actions center-align">
						<a href="<?php echo e(url('admin/works/edit/'.$value->id)); ?>"><i class="large material-icons" title="Edit">edit</i></a>
						<a onclick="works.deleteWork(<?php echo e($value->id); ?>, this)"><i class="large material-icons" title="Delete">clear</i></a>
						<a onclick="works.changeWorkStatus(<?php echo e($value->id); ?>, this)"><i class="large material-icons" title="Delete">
							<?php if($value->status == 0): ?> star_border <?php else: ?> star <?php endif; ?>
						</i></a>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">
			<div class="col s12 right-align">
        		<?php echo e($Works->links()); ?>
        	</div>
		</div>
	</div>
</div>        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
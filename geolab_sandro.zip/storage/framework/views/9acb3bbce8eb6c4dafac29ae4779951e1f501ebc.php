       
<?php $__env->startSection('section'); ?>

<div class="row about-content">
	<form action="<?php echo e(url('admin/about/edit')); ?>" class="file-form" method="post" onsubmit="return admin.submitForm(this);" enctype="multipart/form-data">
		<div class="input-field col s6">
			<input id="Title" name="Title" type="text" data-error="*" value="<?php echo e($Data->title); ?>">
			<label class="active" for="Title">Title</label>
		</div>
		<div class="input-field col s12">
	    	<textarea id="Description" name="Description" class="materialize-textarea" rows="5" data-error="*"><?php echo e($Data->description); ?></textarea>
	    	<label for="Description">Description</label>
	    </div>
	    <div class="input-field col s12 right-align">
	    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	    	<button class="waves-effect waves-light btn-small btn" type="submit">Update</button>
	    </div>
	</form>
</div>        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub_footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
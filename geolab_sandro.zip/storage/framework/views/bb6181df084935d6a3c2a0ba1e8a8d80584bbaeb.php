       
<?php $__env->startSection('section'); ?>

<div class="row categories-add-content pd-all-40">
	<form action="<?php echo e(url('admin/categories/editCategory')); ?>" method="post" onsubmit="return admin.submitForm(this);">
		<div class="input-field col s12">
			<input id="Title" name="Title" type="text" data-error="*" value="<?php echo e($Data->title); ?>">
			<label class="active" for="Title">Title</label>
		</div>
	    <div class="input-field col s12 right-align">
	    	<input type="hidden" name="CatID" value="<?php echo e($Data->id); ?>">
	    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	    	<button class="waves-effect waves-light btn-small" type="submit">Edit</button>
	    </div>
	</form>
</div>        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
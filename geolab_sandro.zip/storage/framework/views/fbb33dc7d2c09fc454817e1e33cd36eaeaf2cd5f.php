<?php $__currentLoopData = $Works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a class="each-work  col l4 m4 s12" onclick="projects.show(<?php echo e($value->id); ?>, <?php echo e($slugID ? $slugID : 0); ?>)"  data-aos="fade-up" data-aos-delay="100" data-aos-duration="700" data-aos-offset="10">
		<?php if($value->file): ?>
		<div class="image" style="background-image: url(<?php echo e(asset('storage/works') . '/' . $value->file); ?>)"></div>
		<?php elseif($value->video): ?>
		<div class="image video-mobile-hidden" style="background-image: url(<?php echo e($value->video_thumb); ?>)">
			<img class="video-play-ico" src="<?php echo e(asset('img/video-play.svg')); ?>">
		</div>
		<?php endif; ?>
	</a>
	<div class="hidden-responsive-text col s12">
		<?php if($value->video): ?>
		<div class="mobile-video-visible">
			<iframe src="<?php echo e($value->video_embed); ?>" width="100%" height="240" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
		</div>
		<?php endif; ?>
		<div class="text">
			<div class="title hidden">
				<?php echo e($value->title); ?>

			</div>
			<p class="tags hidden">
				<?php $__currentLoopData = $value->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagKey => $tagVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="#">#<?php echo e($tagVal->name); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</p>
			<p class="text-body hidden">
				<?php echo e($value->description); ?>

			</p>
		</div>
		<div class="text-footer">
			<a href="" class="share hidden">
				<img src="<?php echo e(asset('img/share.svg')); ?>" alt="" class="left">
				Share This
			</a>
			<time class="right hidden">july 4, 2018</time>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>

<!-- content start -->

<section class="container">
	<div class="about-content row">
		<div class="col l8 m8 s10 offset-l2 offset-m2 offset-s1">
			<div class="animation about hidden">
				<?php include '../public/animations/software-souls/demo.php' ?>
			</div>
			<div class="title hidden">
				<?php echo e($About->title); ?>
			</div>
			<div class="text hidden">
				<?php echo e($About->description); ?>
			</div>
		</div>
	</div>
</section>

<!-- content end -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
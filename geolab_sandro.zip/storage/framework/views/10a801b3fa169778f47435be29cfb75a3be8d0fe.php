       
<?php $__env->startSection('section'); ?>

<div class="row about-content">
	<form action="<?php echo e(url('admin/contact/edit')); ?>" method="post" onsubmit="return admin.submitForm(this);">
		<div class="input-field col s12">
			<input id="Email" name="Email" type="text" data-error="*" value="<?php echo e($Data->email); ?>" onfocusout="return CheckEmail(this)">
			<label class="active" for="Email">Email</label>
		</div>
		<div class="input-field col s12">
			<input id="Phone" name="Phone" type="text" data-error="*" value="<?php echo e($Data->phone); ?>" onkeydown="validate(event, 'int');">
			<label class="active" for="Phone">Phone</label>
		</div>

		<?php $__currentLoopData = config('constants.socials'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SocKey => $Soc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="input-field col s12 contact-socials">
				<?php echo config('constants.socialIcons')[$SocKey]; ?>
		        <input id="Social-<?php echo e($SocKey); ?>" type="text" name="Socials[]" data-error="*" value="<?php echo e($Socials[$SocKey]); ?>">
		        <label for="Social-<?php echo e($SocKey); ?>"><?php echo e($Soc); ?></label>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	    <div class="input-field col s12 right-align">
	    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	    	<button class="waves-effect waves-light btn-small" type="submit">Update</button>
	    </div>
	</form>
</div>        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
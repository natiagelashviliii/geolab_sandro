<div class="popup-inside">
	<div class="row">
		<div class="col m7 image-block hide-on-small-only">
			<?php if($work->file): ?>
			<div class="image" style="background-image: url(<?php echo e(asset('storage/works') . '/' . $work->file); ?>)"></div>
			<?php elseif($work->video): ?>
			<iframe src="<?php echo e($work->video_embed); ?>" width="500" height="500" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
			<?php endif; ?>
		</div>
		<div class="col m5">
			<div class="text">
				<div class="title">
					<?php echo e($work->title); ?>
				</div>
				<p class="tags">
					<?php if($tags): ?>
						<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a href="#">#<?php echo e($value); ?></a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</p>
				<p class="text-body">
					<?php echo e($work->description); ?>
				</p>
			</div>
			<div class="text-footer">
				<a href="" class="share">
					<img src="<?php echo e(asset('img/share.svg')); ?>" alt="" class="left">
					Share This
				</a>
				<time class="right date-time">july 4, 2018</time>
			</div>
		</div>
	</div>
</div>
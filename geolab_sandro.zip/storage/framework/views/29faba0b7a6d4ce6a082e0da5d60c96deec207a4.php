<?php $__env->startSection('content'); ?>

<!-- content start -->

<style type="text/css">
	iframe{
		border: none;
	}
	.spinner {
	  margin: 30px auto 0;
	  width: 70px;
	  text-align: center;
	}

	.spinner > div {
	  width: 8px;
	  height: 8px;
	  background-color: rgba(155,155,155,0.8);
	  margin: 0 4px;
	  border-radius: 100%;
	  display: inline-block;
	  -webkit-animation: sk-bouncedelay 1.4s infinite ease-in-out both;
	  animation: sk-bouncedelay 1.4s infinite ease-in-out both;
	}

	.spinner .bounce1 {
	  -webkit-animation-delay: -0.32s;
	  animation-delay: -0.32s;
	}

	.spinner .bounce2 {
	  -webkit-animation-delay: -0.16s;
	  animation-delay: -0.16s;
	}

	@-webkit-keyframes sk-bouncedelay {
	  0%, 80%, 100% { -webkit-transform: scale(0) }
	  40% { -webkit-transform: scale(1.0) }
	}

	@keyframes  sk-bouncedelay {
	  0%, 80%, 100% { 
	    -webkit-transform: scale(0);
	    transform: scale(0);
	  } 40% { 
	    -webkit-transform: scale(1.0);
	    transform: scale(1.0);
	  }
	}
	.video-play-ico{
		position: absolute;
    	width: 17px;
    	right: 5px;
    	bottom: 5px;
	}
	.popup-inside.new.next{
		opacity: 1;
		transform: translateX(150%);
	}
	.popup-inside.new.previous{
		opacity: 1;
		transform: translateX(-150%);
	}
	@media  only screen and (max-width: 600px) {
		.video-mobile-hidden{
			display: none;
		}
	}
</style>

<section class="container wokrs-container">
	<div class="works-content">
		<div id="filter-menu" class="tabs-head hidden">
			<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e('/works/' . str_slug($value->title,'-')); ?>" class="<?php echo e($slugID == $value->id ? 'active' : ''); ?>" data-slug="<?php echo e(str_slug($value->title,'-')); ?>" data-aos="fade-up" data-aos-delay="10" data-aos-duration="1000" data-aos-offset="10">
					<?php echo e($value->title); ?>

				</a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">

			<div id="illustrations" class="col s12">
				<div id="illustrations-container" class="row">
					<?php echo $__env->make('works.works', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- popup slider content start -->

<!-- popup slider content end -->

<!-- content end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
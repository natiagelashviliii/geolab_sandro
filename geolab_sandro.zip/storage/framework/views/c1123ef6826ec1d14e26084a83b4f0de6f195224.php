</main>



<!-- main end -->



<!-- footer start -->



<footer <?php if(Request::is('/') || Request::is('main') || Request::is('contact') || Request::is('404')): ?> class="footer-main-fixed" <?php endif; ?>  data-aos="fade-up" data-aos-delay="10" data-aos-duration="1000" data-aos-offset="10">

    <?php if(!Request::is('works')): ?>

    <div class="socials container right-align hidden">

        <ul>

            <?php $__currentLoopData = config('constants.socials'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SocKey => $Soc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($Socials[$SocKey]): ?>

                    <li>

                        <a href="<?php echo e($Socials[$SocKey]); ?>" target="_blank">

                            <?php echo e($Soc); ?>


                        </a>

                    </li>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>

    <?php endif; ?>

</footer>



<!-- footer end -->
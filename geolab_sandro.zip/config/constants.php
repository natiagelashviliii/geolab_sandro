<?php 

	return [
		'socials' => [0 => 'vimeo', 1 => 'instagram', 2 => 'youtube'],
		'socialIcons' => [
			0 => '<i class="fa fa-vimeo prefix" aria-hidden="true"></i>', 
			1 => '<i class="fa fa-instagram prefix" aria-hidden="true"></i>',
			2 => '<i class="fa fa-youtube-play prefix" aria-hidden="true"></i>'],
	];

 ?>
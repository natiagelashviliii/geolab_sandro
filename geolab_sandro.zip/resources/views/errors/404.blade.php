@extends ('index')

@section('content')

<!-- content start -->

<section class="container">
	<div class="error-404">
		<div>
			<div class="number">404</div>
			<p class="error-title">oops, sorry page not found</p>
			<p class="error-message">either something went wrong or the page doesn’t exists anymore.</p>
			<a href="index.php">go back please . . .</a>
		</div>
	</div>
</section>

<!-- content end -->

@endsection